<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel = "stylesheet" href = "styles/style.css">
</head>
<body>
    <table>
        <tr>
            <td><a href = "#">Войти | </a></td> 
            <td><a href = "#">Новая запись | </a></td> 
            <td><a href = "#">Отправить сообщение | </a></td> 
            <td><a href = "#">Фото | </a></td>
            <td><a href = "#">Файлы | </a></td>
            <td><a href = "#">Администратору | </a></td>
            <td><a href = "inform.htm">Информация | </a></td>
            <td><a href = "#">Выйти</a></td>
        </tr>
    </table>
    <div id="italic">
        <p>Рад приветствовать вас</p>
        <p>на страницах моего сайта, посвященного путешествиям</p>
        <p>Здесь я буду расказывать о своих путешествиях</p>
        <p>... и выкладывать разные интересные материалы!</p>
    </div>
    <?php 
        require_once("scripts/my_site_db.php");
        $request = "SELECT * FROM MySiteDBMakeevsky.notes";
        echo "<table border = '1px solid black'>
        <tr><td>id</td><td>Создано</td><td>title</td><td>article</td></tr><tr>";
        if($result = $link->query($request)){
            foreach($result as $row){
                echo "<td>" . $row["id"] . "</td>";
                echo "<td>" . $row["created"] . "</td>";
                echo "<td>" . $row["article"] . "</td>"; 
                echo "<td><a href = 'scripts/comments.php?note'> Посмотреть комментарий</a></td></tr>";
            }
        }
        echo "</table>";
        $result->free();
    ?>
</body>
</html>