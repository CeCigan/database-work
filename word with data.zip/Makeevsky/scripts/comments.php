<?php 
require_once("my_site_db.php");
    $localhost = "localhost";
    $user = "root";
    $password = "";

    $link = mysqli_connect($localhost, $user, $password) or trigger_error(mysqli_error($link),E_USER_ERROR);

    $note_id = $_GET["note"];
    $query = "SELECT created, title, article FROM notes WHERE id = $note_id"; 
    $query_comments = "SELECT * FROM comments WHERE art_id =$note_id";
    
    if($result = mysqli_query($link, $query)){
        $rowsCount =  mysqli_num_rows($result);
        echo "Полученно объектов " . $rowsCount;
        echo "<table border = '1px solid black'>
        <tr><td>id</td><td>Создано</td><td>Заголовок</td><td>Содержание</td></tr><tr>";
        foreach($result as $note){
            echo "<td>" . $note["created"] . "</td>";
            echo "<td>" . $note["title"] . "</td>"; 
            echo "<td>" . $note["content"] . "</td>";
            if($result = mysqli_query($link, $query_comments)){
                echo "<td>" . $note["content"] . "</td></tr>";
            }
        }
    
    echo "</table>";
    mysqli_free_result($result);
    } else {
        echo "error" . mysqli_error($link);
    }
?>