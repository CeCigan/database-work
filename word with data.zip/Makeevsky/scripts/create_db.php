<?php
    $connect = mysqli_connect("localhost", "root", "");
    if(!$connect){
        die("Ошибка соединения" .  mysqli_connect_error());
    } else{
        echo "Успех!";
    }

    $sql = "CREATE DATABASE MySiteDBMakeevsky";
    if($connect ->query($sql) === true){
        echo "Бд успешно создана!";
    } else{
        echo "Ошибка создания!" . $connect->error;
    }
?>