<?php 
    $connect = mysqli_connect("localhost", "root", "");
    if(!$connect){
        die("Ошибка соединения" .  mysqli_connect_error());
    } else{
        echo "Успех!";
    }
    $sql = "CREATE TABLE notes(
        id SMAILLINT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        created date(),
        VARCHAR(50),
        ARCTICLE(255))";

    if($connect ->query($sql) === true){
        echo "Таблица создана!";
    } else{
        echo ("Ошибка" . mysqli_error($connect));
    }
?>