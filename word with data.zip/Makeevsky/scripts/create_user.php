<?php 
    $connect = mysqli_connect("localhost", "root", "");
    if(!$connect){
        die("Ошибка соединения" .  mysqli_connect_error());
    } else{
        echo "Успех!";
    }

    $setNewUser = "GRANT ALL PRIVILEGES ON *.* TO 'admin'@'localhost' IDENTIFIED BY 'admin' WITH GRANT OPTION";
    if($connect ->query($setNewUser) === true){
        echo "Пользователь создан!";
    } else{
        echo "Ошибка создания!" . $connect->error;
    }
?>