<?php
    $localhost = "localhost";
    $db = "MySiteDBMakeevsky";
    $user = "root";
    $password = "";

    $link = mysqli_connect($localhost, $user, $password) or
    trigger_error(mysqli_error($link),E_USER_ERROR);
    //trigger_error выводит на страницу сообщение об ошибке. Первый параметр
    //- сообщение об ошибке
    //в строковом виде, в данном случае возвращается функция mysql_error(),
    //второй - числовой код //ошибки(почти всегда используется значение
    //константы E_USER_ERROR, равное 256)

    //Следующие строки необходимы для того, чтобы MySQL воспринимал
    //кириллицу.
    //Параметры функции mysqli_query(): идентификатор соединения с сервером
    // запрос SQL
    mysqli_query($link, "SET NAMES cp1251;") or die(mysqli_error($link));
    mysqli_query($link, "SET CHARACTER SET cp1251;") or die(mysqli_error($link));
?>
